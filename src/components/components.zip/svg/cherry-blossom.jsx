import React from 'react';

const CherryBlossom = () => {
    return (
        <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
		viewBox="0 0 421.95 421.95" style="enable-background:new 0 0 421.95 421.95;"
		xml:space="preserve">
		</svg>

    );
}

export default CherryBlossom;
